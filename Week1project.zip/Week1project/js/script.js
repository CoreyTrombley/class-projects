$(document).ready(function () {

    $('#wrapper').hide();

    $('#wrapper').fadeIn( 5000);

});